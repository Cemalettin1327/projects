using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
  
public class PlayerData
{
	/*public string str;
    public bool boolsw;
    public int gold;
	public bool data_test;*/
	

	
	public int pixelcount;
	public int globaltexture;
	public string anisofilter;
	public int antialiasing;
	public bool softparticles;
	public bool realtimeprobes;
	public bool billboardsface;
	public float fixeddpi;
	public bool texturestreaming;
	public string shadowmaskmode;
	public string shadows;
	public string shadowresolution;
	public string shadowprojection;
	public int shadowdistance;
	public int nearplane;
	public int cascades;
	public string skinweights;
	public int vsynccount;
	public int lodbias;
	public int maxlodlevel;
	public int raycastbudget;
	public int asyncslice;
	public int asyncbuffer;
	public bool persistentbuffer;
	
	public string qualitylevel;
	public int resolutionX;
	public int resolutionY;
	public int aspectX;
	public int aspectY;
    public string renderingpath;
	public int fps;
	public int renderdistance;
	public bool aspectedit;
	public bool resolutionedit;
	public bool probeedit;
	
	
	public float probeboxsize;
	public int proberesolution;
	public float probeintensity;
	public string proberefleshmode;
	public string probemode;
	public string probetimeslicingmode;
	
	public bool lightweightmaterials;
	
	
	public float postweight;
	public bool bloomactive;
	public bool bloomedit;
	public float bloomintensity;
	public float bloomthreshold;
	public float softknee;
	public int clamp;
	public float diffusion;
	public float anamorphicratio;
	public string bloomcolor;
	public bool bloomfastmode;
	public string dirttexture;
	public float bloomdirtintensity;
	
	public bool aberrationactive;
	public bool aberrationedit;
	public string lut;
	public float aberrationintensity;
	public bool aberrationfastmode;
	
	public bool occlusionactive;
	public bool occlusionedit;
	public string occlusionmode;
	public float occlusionintensity;
	public float occlusionradius;
	public string occlusionquality;
	public string occlusioncolor;
	public bool ambientonly;
	
	public bool exposureactive;
	public bool exposureedit;
	public float filteringx;
	public float filteringy;
	public float compensation;
	public string exposuretype;
	public float speedup;
	public float speeddown;
	
	public bool gradingactive;
	public bool depthactive;
	public bool motionactive;
	public bool grainactive;
	public bool vignetteactive;
	public bool distortionactive;
	public bool ssractive;
	public bool postactive;
}
  
public class SaveLoadJSON : MonoBehaviour
{
    public PlayerData playerData;
    string saveFilePath;
		//public bool test;
	
	public int _pixelcount=3;
	public int _globaltexture=0;
	public string _anisofilter="enable";
	public int _antialiasing=0;
	public bool _softparticles=false;
	public bool _realtimeprobes=true;
	public bool _billboardsface=false;
	public float _fixeddpi=1f;
	public bool _texturestreaming=false;
	public string _shadowmaskmode="shadowmask";
	public string _shadows="enable";
	public string _shadowresolution="high";
	public string _shadowprojection="stablefit";
	public int _shadowdistance=150;
	public int _nearplane=3;
	public int _cascades=0;
	public string _skinweights="onebone";
	public int _vsynccount=0;
	public int _lodbias=2;
	public int _maxlodlevel=0;
	public int _raycastbudget=4;
	public int _asyncslice=2;
	public int _asyncbuffer=16;
	public bool _persistentbuffer=true;
	
	public string _qualitylevel="nan";
	public int _resolutionX=680;
	public int _resolutionY=320;
	public int _aspectX=16;
	public int _aspectY=9;
    public string _renderingpath="deferred";
	public int _fps=30;
	public int _renderdistance=1000;
	public bool _aspectedit=false;
	public bool _resolutionedit=false;
	public bool _probeedit=false;
	
	public float _probeboxsize=100f;
	public int _proberesolution=100;
	public float _probeintensity=1f;
	public string _proberefleshmode="everyframe";
	public string _probemode="realtime";
	public string _probetimeslicingmode="allfacesatonce";
	
	public bool _lightweightmaterials=false;
	
	
	public float _postweight=1f;
	public bool _bloomactive=false;
	public bool _bloomedit=false;
	public float _bloomintensity;
	public float _bloomthreshold;
	public float _softknee;
	public int _clamp;
	public float _diffusion;
	public float _anamorphicratio;
	public string _bloomcolor;
	public bool _bloomfastmode;
	public string _dirttexture;
	public float _bloomdirtintensity;
	
	public bool _aberrationactive=false;
	public bool _aberrationedit=false;
	public string _lut;
	public float _aberrationintensity;
	public bool _aberrationfastmode;
	
	public bool _occlusionactive=false;
	public bool _occlusionedit=false;
	public string _occlusionmode;
	public float _occlusionintensity;
	public float _occlusionradius;
	public string _occlusionquality;
	public string _occlusioncolor;
	public bool _ambientonly;
	
	public bool _exposureactive=false;
	public bool _exposureedit=false;
	public float _filteringx;
	public float _filteringy;
	public float _compensation;
	public string _exposuretype;
	public float _speedup;
	public float _speeddown;
	
	public bool _gradingactive=false;
	public bool _depthactive=false;
	public bool _motionactive=false;
	public bool _grainactive=false;
	public bool _vignetteactive=false;
	public bool _distortionactive=false;
	public bool _ssractive=false;
	public bool _postactive=false;
	
	public void Loads(){
	_pixelcount=playerData.pixelcount;
	_globaltexture=playerData.globaltexture;
	_anisofilter=playerData.anisofilter;
	_antialiasing=playerData.antialiasing;
	_softparticles=playerData.softparticles;
	_realtimeprobes=playerData.realtimeprobes;
	_billboardsface=playerData.billboardsface;
	_fixeddpi=playerData.fixeddpi;
	_texturestreaming=playerData.texturestreaming;
	_shadowmaskmode=playerData.shadowmaskmode;
	_shadows=playerData.shadows;
	_shadowresolution=playerData.shadowresolution;
	_shadowprojection=playerData.shadowprojection;
	_shadowdistance=playerData.shadowdistance;
	_nearplane=playerData.nearplane;
	_cascades=playerData.cascades;
	_skinweights=playerData.skinweights;
	_vsynccount=playerData.vsynccount;
	_lodbias=playerData.lodbias;
	_maxlodlevel=playerData.maxlodlevel;
	_raycastbudget=playerData.raycastbudget;
	_asyncslice=playerData.asyncslice;
	_asyncbuffer=playerData.asyncbuffer;
	_persistentbuffer=playerData.persistentbuffer;
	
	_qualitylevel=playerData.qualitylevel;
	_resolutionX=playerData.resolutionX;
	_resolutionY=playerData.resolutionY;
	_aspectX=playerData.aspectX;
	_aspectY=playerData.aspectY;
    _renderingpath=playerData.renderingpath;
	_fps=playerData.fps;
	_renderdistance=playerData.renderdistance;
	_aspectedit=playerData.aspectedit;
	_resolutionedit=playerData.resolutionedit;
	_probeedit=playerData.probeedit;
	
	
	_probeboxsize=playerData.probeboxsize;
	_proberesolution=playerData.proberesolution;
	_probeintensity=playerData.probeintensity;
	_proberefleshmode=playerData.proberefleshmode;
	_probemode=playerData.probemode;
	_probetimeslicingmode=playerData.probetimeslicingmode;
	
	_lightweightmaterials=playerData.lightweightmaterials;
	
	
	
	_postweight=playerData.postweight;
	
	_bloomactive=playerData.bloomactive;
	_bloomedit=playerData.bloomedit;
	_bloomintensity=playerData.bloomintensity;
	_bloomthreshold=playerData.bloomthreshold;
	_softknee=playerData.softknee;
	_clamp=playerData.clamp;
	_diffusion=playerData.diffusion;
	_anamorphicratio=playerData.anamorphicratio;
	_bloomcolor=playerData.bloomcolor;
	_bloomfastmode=playerData.bloomfastmode;
	_dirttexture=playerData.dirttexture;
	_bloomdirtintensity=playerData.bloomdirtintensity;
	
	_aberrationactive=playerData.aberrationactive;
	_aberrationedit=playerData.aberrationedit;
	_lut=playerData.lut;
	_aberrationintensity=playerData.aberrationintensity;
	_aberrationfastmode=playerData.aberrationfastmode;
	
	_occlusionactive=playerData.occlusionactive;
	_occlusionedit=playerData.occlusionedit;
	_occlusionmode=playerData.occlusionmode;
	_occlusionintensity=playerData.occlusionintensity;
	_occlusionradius=playerData.occlusionradius;
	_occlusionquality=playerData.occlusionquality;
	_occlusioncolor=playerData.occlusioncolor;
	_ambientonly=playerData.ambientonly;
	
	_exposureactive=playerData.exposureactive;
	_exposureedit=playerData.exposureedit;
	_filteringx=playerData.filteringx;
	_filteringy=playerData.filteringy;
	_compensation=playerData.compensation;
	_exposuretype=playerData.exposuretype;
	_speedup=playerData.speedup;
	_speeddown=playerData.speeddown;
	
	_gradingactive=playerData.gradingactive;
	_depthactive=playerData.depthactive;
	_motionactive=playerData.motionactive;
	_grainactive=playerData.grainactive;
	_vignetteactive=playerData.vignetteactive;
	_distortionactive=playerData.distortionactive;
	_ssractive=playerData.ssractive;
	_postactive=playerData.postactive;
	}
	
    public void Startcodes(){
	playerData.pixelcount=_pixelcount;
	playerData.globaltexture=_globaltexture;
	playerData.anisofilter=_anisofilter;
	playerData.antialiasing=_antialiasing;
	playerData.softparticles=_softparticles;
	playerData.realtimeprobes=_realtimeprobes;
	playerData.billboardsface=_billboardsface;
	playerData.fixeddpi=_fixeddpi;
	playerData.texturestreaming=_texturestreaming;
	playerData.shadowmaskmode=_shadowmaskmode;
	playerData.shadows=_shadows;
	playerData.shadowresolution=_shadowresolution;
	playerData.shadowprojection=_shadowprojection;
	playerData.shadowdistance=_shadowdistance;
	playerData.nearplane=_nearplane;
	playerData.cascades=_cascades;
	playerData.skinweights=_skinweights;
	playerData.vsynccount=_vsynccount;
	playerData.lodbias=_lodbias;
	playerData.maxlodlevel=_maxlodlevel;
	playerData.raycastbudget=_raycastbudget;
	playerData.asyncslice=_asyncslice;
	playerData.asyncbuffer=_asyncbuffer;
	playerData.persistentbuffer=_persistentbuffer;
	
	playerData.qualitylevel=_qualitylevel;
	playerData.resolutionX=_resolutionX;
	playerData.resolutionY=_resolutionY;
	playerData.aspectX=_aspectX;
	playerData.aspectY=_aspectY;
	playerData.renderingpath=_renderingpath;
	playerData.fps=_fps;
	playerData.renderdistance=_renderdistance;
	playerData.aspectedit=_aspectedit;
	playerData.resolutionedit=_resolutionedit;
	playerData.probeedit=_probeedit;
	
	playerData.probeboxsize=_probeboxsize;
	playerData.proberesolution=_proberesolution;
	playerData.probeintensity=_probeintensity;
	playerData.proberefleshmode=_proberefleshmode;
	playerData.probemode=_probemode;
	playerData.probetimeslicingmode=_probetimeslicingmode;
	
	playerData.lightweightmaterials=_lightweightmaterials;
	
	
	
	playerData.postweight=_postweight;
	playerData.bloomactive=_bloomactive;
	playerData.bloomedit=_bloomedit;
	playerData.bloomintensity=10f;
	playerData.bloomthreshold=0.8f;
	playerData.softknee=0f;
	playerData.clamp=65472;
	playerData.diffusion=7f;
	playerData.anamorphicratio=-1f;
	playerData.bloomcolor="white";
	playerData.bloomfastmode=true;
	playerData.dirttexture="none";
	playerData.bloomdirtintensity=5f;
	
	playerData.aberrationactive=_aberrationactive;
	playerData.aberrationedit=_aberrationedit;
	playerData.lut="none";
	playerData.aberrationintensity=0.25f;
	playerData.aberrationfastmode=true;
	
	playerData.occlusionactive=_occlusionactive;
	playerData.occlusionedit=_occlusionedit;
	playerData.occlusionmode="none";
	playerData.occlusionintensity=4f;
	playerData.occlusionradius=1f;
	playerData.occlusionquality="none";
	playerData.occlusioncolor="black";
	playerData.ambientonly=false;
	
	playerData.exposureactive=_exposureactive;
	playerData.exposureedit=_exposureedit;
	playerData.filteringx=0;
	playerData.filteringy=0;
	playerData.compensation=0.3f;
	playerData.exposuretype="none";
	playerData.speedup=2f;
	playerData.speeddown=1f;
	
	playerData.gradingactive=_gradingactive;
	playerData.depthactive=_depthactive;
	playerData.motionactive=_motionactive;
	playerData.grainactive=_grainactive;
	playerData.vignetteactive=_vignetteactive;
	playerData.distortionactive=_distortionactive;
	playerData.ssractive=_ssractive;
	playerData.postactive=_postactive;
	}
  
    void Start()
    {
        playerData = new PlayerData();
		
		/*playerData.str = "writed";
        playerData.gold = 5;
		playerData.boolsw = true;*/
		
        Startcodes();
  
        saveFilePath = Application.persistentDataPath + "/PlayerData.json";
		
		LoadGame();
    }
  
    /*void Update()
    {
        if (Input.GetKeyDown(KeyCode.S))
            SaveGame();
  
        if (Input.GetKeyDown(KeyCode.L))
            LoadGame();
  
        if (Input.GetKeyDown(KeyCode.D))
            DeleteSaveFile();
		
		 //test=playerData.data_test;
    }*/
  
    public void SaveGame()
    {
		Startcodes();
        string savePlayerData = JsonUtility.ToJson(playerData);
        File.WriteAllText(saveFilePath, savePlayerData);
  
        Debug.Log("Save file created at: " + saveFilePath);
    }
  
    public void LoadGame()
    {
        if (File.Exists(saveFilePath))
        {Invoke("Loads", 0.5f);
            string loadPlayerData = File.ReadAllText(saveFilePath);
            playerData = JsonUtility.FromJson<PlayerData>(loadPlayerData);
  
            //Debug.Log("Load game complete! \n" + playerData.boolsw + playerData.str + ", Player gold: " + playerData.gold);
        }
        else{Debug.Log("There is no save files to load!"); SaveGame();}
        //if(playerData.str=="writed"){Debug.Log("YESSSSSSSSS");}
		
		
    }
  
    public void DeleteSaveFile()
    {
        if (File.Exists(saveFilePath))
        {
            File.Delete(saveFilePath);
  
            Debug.Log("Save file deleted!");
        }
        else{Debug.Log("There is nothing to delete!");}
    }
}