using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class settingsUI : MonoBehaviour
{
	public SaveLoadJSON savescript;
	public GameObject options;
	public Text description_header;
	public Text description;
	public GameObject selection_stats;
	public GameObject selection_renderpath;
	public GameObject selection_renderdistance;
	public GameObject selection_resolution;
	public GameObject selection_aspect;
	public GameObject selection_fps;
	public GameObject selection_pixellight;
	public GameObject selection_globaltexture;
	public GameObject selection_anisofilter;
	public GameObject selection_antialiasing;
	public GameObject selection_softparticles;
	public GameObject selection_realtimeprobes;
	public GameObject selection_billboardsface;
	public GameObject selection_fixeddpi;
	public GameObject selection_texturestreaming;
	public GameObject selection_shadowmaskmode;
	public GameObject selection_shadows;
	public GameObject selection_shadowresolution;
	public GameObject selection_shadowprojection;
	public GameObject selection_shadowdistance;
	public GameObject selection_nearplane;
	public GameObject selection_cascades;
	public GameObject selection_skinweights;
	public GameObject selection_vsynccount;
	public GameObject selection_lodbias;
	public GameObject selection_maxlodlevel;
	public GameObject selection_raycastbudget;
	public GameObject selection_asyncslice;
	public GameObject selection_asyncbuffer;
	public GameObject selection_persistentbuffer;
	//public GameObject selection_qualitylevel;
	public GameObject selection_postprocessing;
	public GameObject selection_postweight;
	public GameObject selection_bloom;
	public GameObject selection_aberration;
	public GameObject selection_occlusion;
	public GameObject selection_exposure;
	public GameObject selection_grading;
	public GameObject selection_depth;
	public GameObject selection_motion;
	public GameObject selection_grain;
	public GameObject selection_vignette;
	public GameObject selection_distortion;
	public GameObject selection_ssr;
	public GameObject selection_post;
	
	public void browsetrue(){options.SetActive(true);}
	public void browsefalse(){options.SetActive(false);}
	
	public void actives(){
		selection_stats.SetActive(false);
		selection_renderpath.SetActive(false);
		selection_renderdistance.SetActive(false);
		selection_resolution.SetActive(false);
		selection_aspect.SetActive(false);
		selection_fps.SetActive(false);
		selection_pixellight.SetActive(false);
		selection_globaltexture.SetActive(false);
		selection_anisofilter.SetActive(false);
		selection_antialiasing.SetActive(false);
		selection_softparticles.SetActive(false);
		selection_realtimeprobes.SetActive(false);
		selection_billboardsface.SetActive(false);
		selection_fixeddpi.SetActive(false);
		selection_texturestreaming.SetActive(false);
		selection_shadowmaskmode.SetActive(false);
		selection_shadows.SetActive(false);
		selection_shadowresolution.SetActive(false);
		selection_shadowprojection.SetActive(false);
		selection_shadowdistance.SetActive(false);
		selection_nearplane.SetActive(false);
		selection_cascades.SetActive(false);
		selection_skinweights.SetActive(false);
		selection_vsynccount.SetActive(false);
		selection_lodbias.SetActive(false);
		selection_maxlodlevel.SetActive(false);
		selection_raycastbudget.SetActive(false);
		selection_asyncslice.SetActive(false);
		selection_asyncbuffer.SetActive(false);
		selection_persistentbuffer.SetActive(false);
		selection_postprocessing.SetActive(false);
		selection_postweight.SetActive(false);
		selection_bloom.SetActive(false);
		selection_aberration.SetActive(false);
		selection_occlusion.SetActive(false);
		selection_exposure.SetActive(false);
		selection_grading.SetActive(false);
		selection_depth.SetActive(false);
		selection_motion.SetActive(false);
		selection_grain.SetActive(false);
		selection_vignette.SetActive(false);
		selection_distortion.SetActive(false);
		selection_ssr.SetActive(false);
		selection_post.SetActive(false);
		}
	
	public void select_stats(){actives(); selection_stats.SetActive(true); description_header.text="build bilgileri"; description.text="[mono BRP Gamma version-cpp BRP Linear version]\n Windows Save file: C:/Users/-User-/AppData/LocalLow/Cemal Özcan/Remake/PlayerData.json \nAndroid Save file: Emulated:/Android/Data/com.cemalozcan.remake/files/PlayerData.json";}
	
	
	public void select_renderpath(){actives(); selection_renderpath.SetActive(true); description_header.text="Camera Rendering Path"+"\n mevcut ayar:"+savescript.playerData.renderingpath; description.text="VERTEX:en basit(yansımalar işlenmez, pixel count 0 seviyesindedir) FORWARD:varsayılan(pixel light count ayarı ayarlanabilir. Bazı durumlarda vertex ayarından daha iyi çalışır.) DEFERRED:en iyi(ssr yansıma sadece bu modda çalışır. pixel count maximum seviyededir ışıklar açılıp kapanıyorsa bu ayarı kullanabilirsiniz.)\n savescript.playerData.renderingpath";}
	public void opt_vertex(){savescript._renderingpath="vertex";  }
	public void opt_forward(){savescript._renderingpath="forward";  }
	public void opt_deferred(){savescript._renderingpath="deferred";  }
	
	public void select_renderdistance(){actives(); selection_renderdistance.SetActive(true); description_header.text="Camera Render distance"+"\n mevcut ayar:"+savescript.playerData.renderdistance; description.text="kamera görüntü mesafesi(bu ayarı azaltmak performansı arttırabilir)\n savescript.playerData.renderdistance";}
	public void opt_renderdistance250(){savescript._renderdistance=250;  }
	public void opt_renderdistance500(){savescript._renderdistance=500;  }
	public void opt_renderdistance1000(){savescript._renderdistance=1000;  }
	
	public void select_resolution(){actives(); selection_resolution.SetActive(true); description_header.text="Resolution"+"\n mevcut ayar:"+savescript.playerData.resolutionY; description.text="geçerli ekran çözünürlüğü(kaliteyi düşürmek performansı yarı yarıya arttırabilir) \n savescript.playerData.resolutionX - savescript.playerData.resolutionY";}
	public void opt_resolutionauto(){savescript._resolutionedit=false;  }
	public void opt_resolution340(){savescript._resolutionedit=true; savescript._resolutionX=340; savescript._resolutionY=180;  }
	public void opt_resolution680(){savescript._resolutionedit=true; savescript._resolutionX=680; savescript._resolutionY=320;  }
	public void opt_resolution720(){savescript._resolutionedit=true; savescript._resolutionX=1280; savescript._resolutionY=720;  }
	
	public void select_aspect(){actives(); selection_aspect.SetActive(true); description_header.text="Aspect"+"\n mevcut ayar:"+savescript.playerData.aspectX; description.text="Aspect Ratio \n savescript.playerData.aspectX - savescript.playerData.aspectY";}
	public void opt_aspectauto(){savescript._aspectedit=false;  }
	public void opt_aspect43(){savescript._aspectedit=true; savescript._aspectX=4; savescript._aspectY=3;  }
	public void opt_aspect169(){savescript._aspectedit=true; savescript._aspectX=16; savescript._aspectY=9;  }
	
	public void select_fps(){actives(); selection_fps.SetActive(true); description_header.text="FPS"+"\n mevcut ayar:"+savescript.playerData.fps; description.text="Ekran Kare Hızı (30fps ayarı ısınmayı ve aşırı güç tüketimini önleyebilir.) \n savescript.playerData.fps";}
	public void opt_fps30(){savescript._fps=30;  }
	public void opt_fps60(){savescript._fps=60;  }
	public void opt_fps120(){savescript._fps=120;  }
	
	public void select_pixelcount(){actives(); selection_pixellight.SetActive(true); description_header.text="pixelcount"+"\n mevcut ayar:"+savescript.playerData.pixelcount; description.text="yakın mesafede detaylı işlenecek ışık sayısı(0 ayarı performansı bir miktar arttırabilir. ışıklar kapanıyorsa bu ayarı yükseltmeyi veya DEFERRED işleme hattı kullanabilirsiniz)\n savescript.playerData.pixelcount";}
    public void opt_pixelcount0(){savescript._pixelcount=0;  }
	public void opt_pixelcount3(){savescript._pixelcount=3;  }
	public void opt_pixelcount5(){savescript._pixelcount=5;  }
	public void opt_pixelcount8(){savescript._pixelcount=8;  }
	
	public void select_globaltexture(){actives(); selection_globaltexture.SetActive(true); description_header.text="texture resolution"+"\n mevcut ayar:"+savescript.playerData.globaltexture; description.text="genel doku çözünürlüğü \n savescript.playerData.globaltexture";}
    public void opt_globaltexture0(){savescript._globaltexture=0;  }
	public void opt_globaltexture1(){savescript._globaltexture=1;  }
	public void opt_globaltexture3(){savescript._globaltexture=3;  }
	
	public void select_anisofilter(){actives(); selection_anisofilter.SetActive(true); description_header.text="aniso filter"+"\n mevcut ayar:"+savescript.playerData.anisofilter; description.text="doku çözünürlük mesafesi \n savescript.playerData.anisofilter";}
    public void opt_anisofilter_disable(){savescript._anisofilter="disable";  }
	public void opt_anisofilter_enable(){savescript._anisofilter="enable";  }
	public void opt_anisofilter_forceenable(){savescript._anisofilter="forceenable";  }

	public void select_antialiasing(){actives(); selection_antialiasing.SetActive(true); description_header.text="antialiasing"+"\n mevcut ayar:"+savescript.playerData.antialiasing; description.text="antialiasing \n savescript.playerData.antialiasing";}
    public void opt_antialiasing_0(){savescript._antialiasing=0;  }
	public void opt_antialiasing_4(){savescript._antialiasing=4;  }
	public void opt_antialiasing_8(){savescript._antialiasing=8;  }
	
	public void select_softparticles(){actives(); selection_softparticles.SetActive(true); description_header.text="softparticles"+"\n mevcut ayar:"+savescript.playerData.softparticles; description.text="yumuşak partiküller \n savescript.playerData.softparticles";}
    public void opt_softparticles_false(){savescript._softparticles=false;  }
	public void opt_softparticles_true(){savescript._softparticles=true;  }

	public void select_realtimeprobes(){actives(); selection_realtimeprobes.SetActive(true); description_header.text="realtimeprobes"+"\n mevcut ayar:"+savescript.playerData.realtimeprobes; description.text="gerçek zamanlı yansımalar(gerçek zamanlı yansımalar cihazı bir miktar zorlayabilir) \n savescript.playerData.realtimeprobes";}
    public void opt_realtimeprobes_false(){savescript._realtimeprobes=false;  }
	public void opt_realtimeprobes_true(){savescript._realtimeprobes=true;  }
	
	public void select_billboardsface(){actives(); selection_billboardsface.SetActive(true); description_header.text="billboardsface"+"\n mevcut ayar:"+savescript.playerData.billboardsface; description.text="billboardsface camera position\n savescript.playerData.billboardsface";}
    public void opt_billboardsface_false(){savescript._billboardsface=false;  }
	public void opt_billboardsface_true(){savescript._billboardsface=true;  }
	
	public void select_fixeddpi(){actives(); selection_fixeddpi.SetActive(true); description_header.text="fixeddpi"+"\n mevcut ayar:"+savescript.playerData.fixeddpi; description.text="inç başına çözünürlük(bu ayarı azaltmak ekran çözünürlüğü gibi performansı arttırabilir)\n savescript.playerData.fixeddpi";}
    public void opt_fixeddpi_025(){savescript._fixeddpi=0.25f;  }
	public void opt_fixeddpi_05(){savescript._fixeddpi=0.5f;  }
	public void opt_fixeddpi_1(){savescript._fixeddpi=1f;  }
	
	public void select_texturestreaming(){actives(); selection_texturestreaming.SetActive(true); description_header.text="texturestreaming"+"\n mevcut ayar:"+savescript.playerData.texturestreaming; description.text="texturestreaming \n savescript.playerData.texturestreaming";}
    public void opt_texturestreaming_false(){savescript._texturestreaming=false;  }
	public void opt_texturestreaming_true(){savescript._texturestreaming=true;  }
	
	public void select_shadowmaskmode(){actives(); selection_shadowmaskmode.SetActive(true); description_header.text="shadowmaskmode"+"\n mevcut ayar:"+savescript.playerData.shadowmaskmode; description.text="shadowmaskmode \n savescript.playerData.shadowmaskmode";}
    public void opt_shadowmaskmode_distance(){savescript._shadowmaskmode="distance";  }
	public void opt_shadowmaskmode_shadowmask(){savescript._shadowmaskmode="shadowmask";  }
	
	public void select_shadows(){actives(); selection_shadows.SetActive(true); description_header.text="shadows"+"\n mevcut ayar:"+savescript.playerData.shadows; description.text="gölge çözünürlüğü \n savescript.playerData.shadows";}
    public void opt_shadows_disable(){savescript._shadows="disable";  }
	public void opt_shadows_hardonly(){savescript._shadows="hardonly";  }
	public void opt_shadows_all(){savescript._shadows="all";  }
	
	public void select_shadowresolution(){actives(); selection_shadowresolution.SetActive(true); description_header.text="shadowresolution"+"\n mevcut ayar:"+savescript.playerData.shadowresolution; description.text="gölge kalitesi (low/med/high/ultra)\n savescript.playerData.shadowresolution";}
    public void opt_shadowresolution_low(){savescript._shadows="low";  }
	public void opt_shadowresolution_med(){savescript._shadows="med";  }
	public void opt_shadowresolution_high(){savescript._shadows="high";  }
	public void opt_shadowresolution_ultra(){savescript._shadows="ultra";  }
	
	public void select_shadowprojection(){actives(); selection_shadowprojection.SetActive(true); description_header.text="shadowprojection"+"\n mevcut ayar:"+savescript.playerData.shadowprojection; description.text="gölge projeksiyonu \n savescript.playerData.shadowprojection";}
    public void opt_shadowprojection_closefit(){savescript._shadowprojection="closefit";  }
	public void opt_shadowprojection_stablefit(){savescript._shadowprojection="stablefit";  }
	
	public void select_shadowdistance(){actives(); selection_shadowdistance.SetActive(true); description_header.text="shadowdistance"+"\n mevcut ayar:"+savescript.playerData.shadowdistance; description.text="gölge mesafesi\n savescript.playerData.shadowdistance";}
    public void opt_shadowdistance0(){savescript._shadowdistance=0;  }
	public void opt_shadowdistance50(){savescript._shadowdistance=50;  }
	public void opt_shadowdistance150(){savescript._shadowdistance=150;  }
	
	public void select_nearplane(){actives(); selection_nearplane.SetActive(true); description_header.text="nearplane"+"\n mevcut ayar:"+savescript.playerData.nearplane; description.text="shadow nearplane offset \n savescript.playerData.nearplane";}
    public void opt_nearplane0(){savescript._nearplane=0;  }
	public void opt_nearplane3(){savescript._nearplane=3;  }
	public void opt_nearplane6(){savescript._nearplane=6;  }
	
	public void select_cascades(){actives(); selection_cascades.SetActive(true); description_header.text="cascades"+"\n mevcut ayar:"+savescript.playerData.cascades; description.text="shadow cascades \n savescript.playerData.cascades";}
    public void opt_cascades0(){savescript._cascades=0;  }
	public void opt_cascades2(){savescript._cascades=2;  }
	public void opt_cascades4(){savescript._cascades=4;  }
	
	public void select_skinweights(){actives(); selection_skinweights.SetActive(true); description_header.text="skinweights"+"\n mevcut ayar:"+savescript.playerData.skinweights; description.text="skin weights(bu ayar ragdoll ve rig için geçerlidir)\n savescript.playerData.skinweights";}
    public void opt_skinweights_onebone(){savescript._skinweights="onebone";  }
	public void opt_skinweights_twobones(){savescript._skinweights="twobones";  }
	public void opt_skinweights_fourbones(){savescript._skinweights="fourbones";  }
	
	public void select_vsynccount(){actives(); selection_vsynccount.SetActive(true); description_header.text="vsynccount"+"\n mevcut ayar:"+savescript.playerData.vsynccount; description.text="vsynccount (bu ayar mobil için önemsizdir)\n savescript.playerData.vsynccount";}
    public void opt_vsynccount0(){savescript._vsynccount=0;  }
	public void opt_vsynccount2(){savescript._vsynccount=2;  }
	public void opt_vsynccount4(){savescript._vsynccount=4;  }
	
	public void select_lodbias(){actives(); selection_lodbias.SetActive(true); description_header.text="lodbias"+"\n mevcut ayar:"+savescript.playerData.lodbias; description.text="LOD Mesafesi sapması \n savescript.playerData.lodbias";}
    public void opt_lodbias0(){savescript._lodbias=0;  }
	public void opt_lodbias2(){savescript._lodbias=2;  }
	public void opt_lodbias4(){savescript._lodbias=4;  }
	
	public void select_maxlodlevel(){actives(); selection_maxlodlevel.SetActive(true); description_header.text="maxlodlevel"+"\n mevcut ayar:"+savescript.playerData.maxlodlevel; description.text="max lod level \n savescript.playerData.maxlodlevel";}
    public void opt_maxlodlevel0(){savescript._maxlodlevel=0;  }
	public void opt_maxlodlevel2(){savescript._maxlodlevel=2;  }
	public void opt_maxlodlevel4(){savescript._maxlodlevel=4;  }
	
	public void select_raycastbudget(){actives(); selection_raycastbudget.SetActive(true); description_header.text="raycastbudget"+"\n mevcut ayar:"+savescript.playerData.raycastbudget; description.text="particle raycast budget\n savescript.playerData.raycastbudget";}
    public void opt_raycastbudget0(){savescript._raycastbudget=0;  }
	public void opt_raycastbudget2(){savescript._raycastbudget=2;  }
	public void opt_raycastbudget4(){savescript._raycastbudget=4;  }
	
	public void select_asyncslice(){actives(); selection_asyncslice.SetActive(true); description_header.text="asyncslice"+"\n mevcut ayar:"+savescript.playerData.asyncslice; description.text="asyncslice(bu ayar mobil için önemsizdir) \n savescript.playerData.asyncslice";}
    public void opt_asyncslice0(){savescript._asyncslice=0;  }
	public void opt_asyncslice2(){savescript._asyncslice=2;  }
	public void opt_asyncslice4(){savescript._asyncslice=4;  }
	
	public void select_asyncbuffer(){actives(); selection_asyncbuffer.SetActive(true); description_header.text="asyncbuffer"+"\n mevcut ayar:"+savescript.playerData.asyncbuffer; description.text="asyncbuffer(bu ayar mobil için önemsizdir)\n savescript.playerData.asyncbuffer";}
    public void opt_asyncbuffer16(){savescript._asyncbuffer=16;  }
	public void opt_asyncbuffer32(){savescript._asyncbuffer=32;  }
	public void opt_asyncbuffer64(){savescript._asyncbuffer=64;  }
	
	public void select_persistentbuffer(){actives(); selection_persistentbuffer.SetActive(true); description_header.text="persistentbuffer"+"\n mevcut ayar:"+savescript.playerData.persistentbuffer; description.text="persistentbuffer \n savescript.playerData.persistentbuffer";}
    public void opt_persistentbuffer_false(){savescript._persistentbuffer=false;  }
	public void opt_persistentbuffer_true(){savescript._persistentbuffer=true;  }
	
	public void select_postweight(){actives(); selection_postweight.SetActive(true); description_header.text="postweight"+"\n mevcut ayar:"+savescript.playerData.postweight; description.text="post processing filtresi görünürlük oranı (0...1)\n savescript.playerData.postweight";}
    public void opt_postweight0(){savescript._postweight=0f;  }
	public void opt_postweight05(){savescript._postweight=0.5f;  }
	public void opt_postweight1(){savescript._postweight=1f;  }
	
	public void select_bloom(){actives(); selection_bloom.SetActive(true); description_header.text="bloom"+"\n mevcut ayar:"+savescript.playerData.bloomactive; description.text="post processing filtresi parlama efekti\n savescript.playerData.bloomactive";}
    public void opt_bloom_false(){savescript._bloomactive=false;  }
	public void opt_bloom_true(){savescript._bloomactive=true;  }
	
	public void select_aberration(){actives(); selection_aberration.SetActive(true); description_header.text="aberration"+"\n mevcut ayar:"+savescript.playerData.aberrationactive; description.text="post processing filtresi renk sapması efekti\n savescript.playerData.aberrationactive";}
    public void opt_aberration_false(){savescript._aberrationactive=false;  }
	public void opt_aberration_true(){savescript._aberrationactive=true;  }
	
	public void select_occlusion(){actives(); selection_occlusion.SetActive(true); description_header.text="occlusion"+"\n mevcut ayar:"+savescript.playerData.occlusionactive; description.text="post processing filtresi detaylı gölgeleme \n savescript.playerData.occlusionactive";}
    public void opt_occlusion_false(){savescript._occlusionactive=false;  }
	public void opt_occlusion_true(){savescript._occlusionactive=true;  }
	
	public void select_exposure(){actives(); selection_exposure.SetActive(true); description_header.text="exposure"+"\n mevcut ayar:"+savescript.playerData.exposureactive; description.text="post processing filtresi otomatik pozlama\n savescript.playerData.exposureactive";}
    public void opt_exposure_false(){savescript._exposureactive=false;  }
	public void opt_exposure_true(){savescript._exposureactive=true;  }
	
	public void select_grading(){actives(); selection_grading.SetActive(true); description_header.text="grading"+"\n mevcut ayar:"+savescript.playerData.gradingactive; description.text="post processing filtresi renk tonu efektleri\n savescript.playerData.gradingactive";}
    public void opt_grading_false(){savescript._gradingactive=false;  }
	public void opt_grading_true(){savescript._gradingactive=true;  }
	
	public void select_depth(){actives(); selection_depth.SetActive(true); description_header.text="depth"+"\n mevcut ayar:"+savescript.playerData.depthactive; description.text="post processing filtresi arkaplan bulanıklığı\n savescript.playerData.depthactive";}
    public void opt_depth_false(){savescript._depthactive=false;  }
	public void opt_depth_true(){savescript._depthactive=true;  }
	
	public void select_motion(){actives(); selection_motion.SetActive(true); description_header.text="motion"+"\n mevcut ayar:"+savescript.playerData.motionactive; description.text="post processing filtresi hareket bulanıklığı(motionblur)\n savescript.playerData.motionactive";}
    public void opt_motion_false(){savescript._motionactive=false;  }
	public void opt_motion_true(){savescript._motionactive=true;  }
	
	public void select_grain(){actives(); selection_grain.SetActive(true); description_header.text="grain"+"\n mevcut ayar:"+savescript.playerData.grainactive; description.text="post processing filtresi karıncalanma efekti\n savescript.playerData.grainactive";}
    public void opt_grain_false(){savescript._grainactive=false;  }
	public void opt_grain_true(){savescript._grainactive=true;  }
	
	public void select_vignette(){actives(); selection_vignette.SetActive(true); description_header.text="vignette"+"\n mevcut ayar:"+savescript.playerData.vignetteactive; description.text="post processing filtresi vinyet\n savescript.playerData.vignetteactive";}
    public void opt_vignette_false(){savescript._vignetteactive=false;  }
	public void opt_vignette_true(){savescript._vignetteactive=true;  }
	
	public void select_distortion(){actives(); selection_distortion.SetActive(true); description_header.text="distortion"+"\n mevcut ayar:"+savescript.playerData.distortionactive; description.text="post processing filtresi mercek yamukluğu\n savescript.playerData.distortionactive";}
    public void opt_distortion_false(){savescript._distortionactive=false;  }
	public void opt_distortion_true(){savescript._distortionactive=true;  }
	
	public void select_ssr(){actives(); selection_ssr.SetActive(true); description_header.text="ssr"+"\n mevcut ayar:"+savescript.playerData.ssractive; description.text="ekran alanı yansıması yanlızca deferred işleme ayarında çalışır.! bu ayar telefonlarda desteklenmeyebilir! uygulama hata verirse playerdata dosyasından ssractive ayarını false yapınız. bu ayarı kullanacaksanız gerçek zamanlı yansımaları devre dışı bırakabilirsiniz.\n savescript.playerData.ssractive";}
    public void opt_ssr_false(){savescript._ssractive=false;  }
	public void opt_ssr_true(){savescript._ssractive=true;  }
	
	public void select_postactive(){actives(); selection_post.SetActive(true); description_header.text="post"+"\n mevcut ayar:"+savescript.playerData.postactive; description.text="post processing filtresi açık/kapalı durumu(post processing filtresi cihazı zorlayabilir.)\n savescript.playerData.postactive";}
    public void opt_post_false(){savescript._postactive=false;  }
	public void opt_post_true(){savescript._postactive=true;  }
	
	public void select_footer(){}
	
	
    // Start is called before the first frame update
    void Start()
    {
         select_stats();
    }

}
