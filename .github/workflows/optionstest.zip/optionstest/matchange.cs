using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class matchange : MonoBehaviour
{
	
	public SaveLoadJSON savescript;
	public Material Material1;
	public GameObject ground;
	
	void wasd(){if(savescript.playerData.lightweightmaterials==true){ground.GetComponent<MeshRenderer>().material = Material1;}}
    // Start is called before the first frame update
    void Start()
    {
        Invoke("wasd", 1f);
    }

    // Update is called once per frame
 
}
