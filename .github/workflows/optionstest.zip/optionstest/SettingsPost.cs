using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
public class SettingsPost : MonoBehaviour
{
	public SaveLoadJSON savescript;
	//public Camera cmr;
	[SerializeField] PostProcessVolume newvolume;
	Bloom _bloom;
	ChromaticAberration _aberration;
	ScreenSpaceReflections _SSR;
	AmbientOcclusion _occlusion;
	AutoExposure _exposure;
	ColorGrading _grading;
	DepthOfField _depth;
	MotionBlur _motion;
	Grain _grain;
	Vignette _vignette;
	LensDistortion _distortion;
	
	public Texture DirtTexture;
	public TextureParameter LUT;
	//public TextureParameter LUT;
	
	public GameObject post;
	

	public void reload(){savescript.LoadGame(); Invoke("wait", 1f);}
	public void wait(){
		newvolume.weight=savescript.playerData.postweight;
		if(savescript.playerData.postactive==true){post.SetActive(true);}
		if(savescript.playerData.postactive==false){post.SetActive(false);}
		_bloom.active=savescript.playerData.bloomactive;
		if(savescript.playerData.bloomedit==true){
		_bloom.intensity.value=savescript.playerData.bloomintensity;
		_bloom.threshold.value=savescript.playerData.bloomthreshold;
		_bloom.softKnee.value=savescript.playerData.softknee;
		_bloom.clamp.value=savescript.playerData.clamp;
		_bloom.diffusion.value=savescript.playerData.diffusion;
		_bloom.anamorphicRatio.value=savescript.playerData.anamorphicratio;
		
		_bloom.fastMode.value=savescript.playerData.bloomfastmode;
		_bloom.dirtTexture.value=DirtTexture;
		_bloom.dirtIntensity.value=savescript.playerData.bloomdirtintensity;
		
		}
		_aberration.active=savescript.playerData.aberrationactive;
		if(savescript.playerData.aberrationedit==true){
		_aberration.intensity.value=savescript.playerData.aberrationintensity;
		_aberration.fastMode.value=savescript.playerData.aberrationfastmode;
		}
		_occlusion.active=savescript.playerData.occlusionactive;
		if(savescript.playerData.occlusionedit==true){
		_occlusion.intensity.value=savescript.playerData.occlusionintensity;
		_occlusion.radius.value=savescript.playerData.occlusionradius;
		
		}
		_exposure.active=savescript.playerData.exposureactive;
		if(savescript.playerData.exposureedit==true){
		_exposure.minLuminance.value=0;
		_exposure.maxLuminance.value=0;
		_exposure.keyValue.value=savescript.playerData.compensation;
		}
		_grading.active=savescript.playerData.gradingactive;
		_depth.active=savescript.playerData.depthactive;
		_motion.active=savescript.playerData.motionactive;
		_grain.active=savescript.playerData.grainactive;
		_vignette.active=savescript.playerData.vignetteactive;
		_distortion.active=savescript.playerData.distortionactive;
		_SSR.active=savescript.playerData.ssractive;
		}
	
	/*public void Set_Bloom_ON(){_bloom.active=true;}
	public void Set_Bloom_OFF(){_bloom.active=false;}
	public void Set_Bloom_Intensity(){_bloom.intensity.value=10;}
	public void Set_Bloom_Threshold(){_bloom.threshold.value=0.8f;}
	public void Set_Bloom_SoftKnee2(){_bloom.softKnee.value=0;}
	public void Set_Bloom_Clamp(){_bloom.clamp.value=65472;}
	public void Set_Bloom_Diffusion(){_bloom.diffusion.value=7;}
	public void Set_Bloom_AnamorphicRatio(){_bloom.anamorphicRatio.value=1;}
	public void Set_Bloom_SoftKnee(){_bloom.softKnee.value=0;}
	public void Set_Bloom_Color(){_bloom.color.value=Color.white;}
	public void Set_Bloom_FastMode(){_bloom.fastMode.value=true;}
	public void Set_Bloom_DirtTexture(){_bloom.dirtTexture=Dirt;}
	public void Set_Bloom_DirtIntensity(){_bloom.dirtIntensity.value=0;}
	
	public void Set_Aberration_ON(){_aberration.active=true;}
	public void Set_Aberration_OFF(){_aberration.active=false;}
	public void Set_Aberration_LUT(){_aberration.spectralLut=LUT;}
	public void Set_Aberration_Intensity(){_aberration.intensity.value=1;}
	public void Set_Aberration_FastMode(){_aberration.fastMode.value=true;}
	
	public void Set_SSR_OFF(){_SSR.active=false;}
	
	public void Set_Occlusion_OFF(){_occlusion.active=false;}
	//public void Set_Occlusion_Mode(){_occlusion.mode.value=ScalableAmbientObscurance;}
	//public void Set_Occlusion_Mode2(){_occlusion.mode.value=MultiScaleVolumetricObscurance;}
	public void Set_Occlusion_Intensity(){_occlusion.intensity.value=1;}
	public void Set_Occlusion_Radius(){_occlusion.radius.value=1;}
	public void Set_Occlusion_Quality0(){_occlusion.quality.value=AmbientOcclusionQuality.Lowest;}
	public void Set_Occlusion_Quality1(){_occlusion.quality.value=AmbientOcclusionQuality.Low;}
	public void Set_Occlusion_Quality2(){_occlusion.quality.value=AmbientOcclusionQuality.Medium;}
	public void Set_Occlusion_Quality3(){_occlusion.quality.value=AmbientOcclusionQuality.High;}
	public void Set_Occlusion_Quality4(){_occlusion.quality.value=AmbientOcclusionQuality.Ultra;}
	public void Set_Occlusion_Color(){_occlusion.color.value=Color.black;}
	public void Set_Occlusion_Only(){_occlusion.ambientOnly.value=true;}
	

	public void Set_Exposure_OFF(){_exposure.active=false;}
	public void Set_Exposure_Filtering(){_exposure.filtering.value=new Vector2(1,1);}
	public void Set_Exposure_minLuminance(){_exposure.minLuminance.value=0;}
	public void Set_Exposure_maxLuminance(){_exposure.maxLuminance.value=0;}
	public void Set_Exposure_Compensation(){_exposure.keyValue.value=0;}
	public void Set_Exposure_Adaptation(){_exposure.eyeAdaptation.value=EyeAdaptation.Progressive;}
	public void Set_Exposure_Adaptation2(){_exposure.eyeAdaptation.value=EyeAdaptation.Fixed;}
	public void Set_Exposure_SpeedUP(){_exposure.speedUp.value=0;}
	public void Set_Exposure_SpeedDOWN(){_exposure.speedDown.value=0;}
	
	
	
	
	public void Set_Grading_OFF(){_grading.active=false;}
	
	
	
	
	
	
	public void Set_Depth_OFF(){_depth.active=false;}
	
	public void Set_Motion_OFF(){_motion.active=false;}
	public void Set_Grain_OFF(){_grain.active=false;}
	public void Set_Vignette_OFF(){_vignette.active=false;}
	public void Set_Distortion_OFF(){_distortion.active=false;}
	*/

	void Awake(){ /*post = GameObject.FindWithTag("post"); */Invoke("wait", 1f); }
    // Start is called before the first frame update
    void Start()
    {
        newvolume=newvolume.GetComponent<PostProcessVolume>();
		newvolume.profile.TryGetSettings(out _bloom);
		newvolume.profile.TryGetSettings(out _aberration);
		newvolume.profile.TryGetSettings(out _SSR);
		newvolume.profile.TryGetSettings(out _occlusion);
		newvolume.profile.TryGetSettings(out _exposure);
		newvolume.profile.TryGetSettings(out _grading);
		newvolume.profile.TryGetSettings(out _depth);
		newvolume.profile.TryGetSettings(out _motion);
		newvolume.profile.TryGetSettings(out _grain);
		newvolume.profile.TryGetSettings(out _vignette);
		newvolume.profile.TryGetSettings(out _distortion);
		
    }


}
