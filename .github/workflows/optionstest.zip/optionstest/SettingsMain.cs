using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.Rendering; //PROBE RENDERING

public class SettingsMain : MonoBehaviour
{
	public SaveLoadJSON savescript;
	public ReflectionProbe probe;
    private Vector3 boxsize;
	public float boxsizex;
    
	
	//public bool x;
	
	public void reload(){savescript.LoadGame(); Invoke("wait", 1f);}
	public void Set_RenderingPath(){/*Camera.main.renderingPath = RenderingPath.DeferredLighting;*/ /*only maincamera tag object*/}
	void Awake(){Invoke("wait", 1f);}
	public void wait(){
		//x=savescript.playerData.data_test;
		Debug.Log("quaity edit");
		
	  QualitySettings.pixelLightCount = savescript.playerData.pixelcount;
	  //QualitySettings.globalTextureMipmapLimit = 1; //newer
	  QualitySettings.masterTextureLimit = savescript.playerData.globaltexture; // 3 very low 0 max
	  if(savescript.playerData.anisofilter=="disable"){QualitySettings.anisotropicFiltering = AnisotropicFiltering.Disable;} //Disable Enable ForceEnable
	  if(savescript.playerData.anisofilter=="enable"){QualitySettings.anisotropicFiltering = AnisotropicFiltering.Enable;} //Disable Enable ForceEnable
	  if(savescript.playerData.anisofilter=="forceenable"){QualitySettings.anisotropicFiltering = AnisotropicFiltering.ForceEnable;} //Disable Enable ForceEnable
	  QualitySettings.antiAliasing = savescript.playerData.antialiasing; //2 4 8
	  QualitySettings.softParticles=savescript.playerData.softparticles;
	  QualitySettings.realtimeReflectionProbes=savescript.playerData.realtimeprobes;
	  QualitySettings.billboardsFaceCameraPosition=savescript.playerData.billboardsface;
	  QualitySettings.resolutionScalingFixedDPIFactor = savescript.playerData.fixeddpi;
	  //QualitySettings.DefinitionScalingFixedDPIFactor=savescript.playerData.fixeddpi;
	  QualitySettings.streamingMipmapsActive = savescript.playerData.texturestreaming;
	  
	  if(savescript.playerData.shadowmaskmode=="distance"){QualitySettings.shadowmaskMode=ShadowmaskMode.DistanceShadowmask;}//Shadowmask
	  if(savescript.playerData.shadowmaskmode=="shadowmask"){QualitySettings.shadowmaskMode=ShadowmaskMode.Shadowmask;}
	  if(savescript.playerData.shadows=="disable"){QualitySettings.shadows = ShadowQuality.Disable;} //ShadowQuality.HardOnly; ShadowQuality.All;
	  if(savescript.playerData.shadows=="hardonly"){QualitySettings.shadows = ShadowQuality.HardOnly;}
	  if(savescript.playerData.shadows=="all"){QualitySettings.shadows = ShadowQuality.All;}
	  
	  if(savescript.playerData.shadowresolution=="low"){QualitySettings.shadowResolution=ShadowResolution.Low;} //Low Medium High VeryHigh
	  if(savescript.playerData.shadowresolution=="med"){QualitySettings.shadowResolution=ShadowResolution.Medium;}
	  if(savescript.playerData.shadowresolution=="high"){QualitySettings.shadowResolution=ShadowResolution.High;}
	  if(savescript.playerData.shadowresolution=="ultra"){QualitySettings.shadowResolution=ShadowResolution.VeryHigh;}
	  
	  if(savescript.playerData.shadowprojection=="closefit"){QualitySettings.shadowProjection=ShadowProjection.CloseFit;} //StableFit
	  if(savescript.playerData.shadowprojection=="stablefit"){QualitySettings.shadowProjection=ShadowProjection.StableFit;}
	  QualitySettings.shadowDistance=savescript.playerData.shadowdistance;
	  QualitySettings.shadowNearPlaneOffset=savescript.playerData.nearplane;
	  QualitySettings.shadowCascades=savescript.playerData.cascades; // 0 2 4
	  
	  if(savescript.playerData.skinweights=="onebone"){QualitySettings.skinWeights = SkinWeights.OneBone;}
	  if(savescript.playerData.skinweights=="twobone"){QualitySettings.skinWeights = SkinWeights.TwoBones;}
	  if(savescript.playerData.skinweights=="fourbone"){QualitySettings.skinWeights = SkinWeights.FourBones;}
	  QualitySettings.vSyncCount=savescript.playerData.vsynccount;
	  QualitySettings.lodBias=savescript.playerData.lodbias;
	  QualitySettings.maximumLODLevel=savescript.playerData.maxlodlevel;
	  QualitySettings.particleRaycastBudget=savescript.playerData.raycastbudget;
	  QualitySettings.asyncUploadTimeSlice = savescript.playerData.asyncslice;
	  QualitySettings.asyncUploadBufferSize = savescript.playerData.asyncbuffer;
	  QualitySettings.asyncUploadPersistentBuffer = savescript.playerData.persistentbuffer;
	  
	  
	  //QualitySettings.SetQualityLevel(0, true);
	  if(savescript.playerData.resolutionedit==true){
	  Screen.SetResolution(savescript.playerData.resolutionX, savescript.playerData.resolutionY, true);
	  }
       if(savescript.playerData.aspectedit==true){
	  Camera.main.aspect = savescript.playerData.aspectX / savescript.playerData.aspectY;
	   }
	  if(savescript.playerData.renderingpath=="vertex"){Camera.main.renderingPath = RenderingPath.VertexLit;}
	  if(savescript.playerData.renderingpath=="forward"){Camera.main.renderingPath = RenderingPath.Forward;}
	  if(savescript.playerData.renderingpath=="deferredlegacy"){Camera.main.renderingPath = RenderingPath.DeferredLighting;}
	  if(savescript.playerData.renderingpath=="deferred"){Camera.main.renderingPath = RenderingPath.DeferredShading;}
	  
	  Camera.main.farClipPlane = savescript.playerData.renderdistance;
	  
	  Application.targetFrameRate = savescript.playerData.fps;
	
	
	if(savescript.playerData.probeedit==true){
		boxsizex=savescript.playerData.probeboxsize;
		boxsize= new Vector3(boxsizex, boxsizex, boxsizex);
        //probe = GetComponent<ReflectionProbe>();
		probe.resolution=savescript.playerData.proberesolution;
		probe.intensity=savescript.playerData.probeintensity;
		probe.size=boxsize;

		if(savescript.playerData.proberefleshmode=="onawake"){probe.refreshMode = ReflectionProbeRefreshMode.OnAwake;}
		if(savescript.playerData.proberefleshmode=="everyframe"){probe.refreshMode = ReflectionProbeRefreshMode.EveryFrame;}
		if(savescript.playerData.proberefleshmode=="viascripting"){probe.refreshMode = ReflectionProbeRefreshMode.ViaScripting;}
        if(savescript.playerData.probemode=="realtime"){probe.mode = ReflectionProbeMode.Realtime;}
		if(savescript.playerData.probemode=="custom"){probe.mode = ReflectionProbeMode.Custom;}
		if(savescript.playerData.probemode=="baked"){probe.mode = ReflectionProbeMode.Baked;}
        if(savescript.playerData.probetimeslicingmode=="allfacesatonce"){probe.timeSlicingMode = ReflectionProbeTimeSlicingMode.AllFacesAtOnce;}
		if(savescript.playerData.probetimeslicingmode=="individualfaces"){probe.timeSlicingMode = ReflectionProbeTimeSlicingMode.IndividualFaces;}
		if(savescript.playerData.probetimeslicingmode=="notimeslicing"){probe.timeSlicingMode = ReflectionProbeTimeSlicingMode.NoTimeSlicing;}
	}
	
	
	}



}
